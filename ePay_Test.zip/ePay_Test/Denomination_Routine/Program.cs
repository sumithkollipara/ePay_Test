﻿using System;

namespace Denomination_Routine
{
    class Program
    {
        static void Main()
        {
            //new Class1().Test();

            try
            {
            StartOver:
                string instruction = "Please press Y to continue....";
                string errorMessage = "Please enter valid amount";

                Print($"Denominations Calculator: \n{errorMessage}:");

                int[] availableDenominations = { 10, 50, 100 };
                var tempInput = Console.ReadLine();
                if (string.IsNullOrEmpty(tempInput))
                {
                    Print(errorMessage + "\n" + instruction);
                    var restartrProcess = Console.ReadLine();
                    if (!string.IsNullOrEmpty(restartrProcess) && restartrProcess.ToUpper() == "Y")
                        goto StartOver;
                }

                var payoutAmount = 0;
                if (int.TryParse(tempInput, out payoutAmount) && payoutAmount % 10 == 0)
                {
                    Print($"Denominations available of: {string.Join(", ", availableDenominations)} are as follows: \n");

                    int allTenCount = payoutAmount / availableDenominations[0];
                    Print(allTenCount + " x " + availableDenominations[0].ToString() + " EUR");

                    int allFiftyCount = payoutAmount / availableDenominations[1];
                    if (allFiftyCount > 0)
                        for (int i = 1; i <= allFiftyCount; i++)
                        {
                            int altTen = (int)((payoutAmount - (availableDenominations[1] * i)) / availableDenominations[0]);
                            if (i > 0 && altTen > 0)
                                Print(i + " x " + availableDenominations[1].ToString() + " EUR + " + altTen + " x " + availableDenominations[0].ToString() + " EUR");
                        }

                    if (payoutAmount % availableDenominations[1] == 0)
                        Print(allFiftyCount + " x " + availableDenominations[1].ToString() + " EUR");

                    int allHundredCount = (int)(payoutAmount / availableDenominations[2]);
                    if (allHundredCount > 0)
                        for (int i = 1; i <= allHundredCount; i++)
                        {
                            int altFifty = (int)((payoutAmount - (availableDenominations[2] * i)) / availableDenominations[1]);
                            if (i > 0 && altFifty > 0 && (payoutAmount % (altFifty * availableDenominations[1] + i * availableDenominations[2]) == 0))
                                Print(i + " x " + availableDenominations[2].ToString() + " EUR + " + altFifty + " x " + availableDenominations[1].ToString() + " EUR");

                            if (altFifty > 0)
                                for (int j = 1; j <= altFifty; j++)
                                {
                                    int altTen = (int)((payoutAmount - ((availableDenominations[2] * i) + (availableDenominations[1] * j))) / availableDenominations[0]);
                                    if (i > 0 && j > 0 && altTen > 0)
                                        Print(i + " x " + availableDenominations[2].ToString() + " EUR + " + j + " x " + availableDenominations[1].ToString() + " EUR + " + +altTen + " x " + availableDenominations[0].ToString() + " EUR");
                                }
                            else
                            {
                                int altTen = (int)((payoutAmount - (availableDenominations[2] * i)) / availableDenominations[0]);
                                if (i > 0 && altTen > 0)
                                    Print(i + " x " + availableDenominations[2].ToString() + " EUR + " + altTen + " x " + availableDenominations[0].ToString() + " EUR");
                            }
                        }

                    if (payoutAmount % availableDenominations[2] == 0)
                        Print(allHundredCount + " x " + availableDenominations[2].ToString() + " EUR");

                    Print(instruction);
                    var restartProgram = Console.ReadLine();
                    if (!string.IsNullOrEmpty(restartProgram) && restartProgram.ToUpper() == "Y")
                        goto StartOver;
                }
                else
                {
                    Print($"Amount should be multiple of 10 EUR.\n{instruction}");

                    var restartProgram = Console.ReadLine();
                    if (!string.IsNullOrEmpty(restartProgram) && restartProgram.ToUpper() == "Y")
                        goto StartOver;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static void Print(string message)
        {
            Console.WriteLine(message);
        }
    }
}
