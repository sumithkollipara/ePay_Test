﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Denomination_Routine
{
    public class Class1
    {
        public static int[] currency;
        public static string result = string.Empty;
        public static List<string> resultList;
        public void Test()
        {
            currency = new int[] { 10, 50, 100 };
            Console.WriteLine("enter the denomination");
            int denom = Convert.ToInt32(Console.ReadLine());
            foreach (int item in currency)
            {
                GetDivision(item, denom);
            }
            Console.Read();
        }

        public void print(string result)
        {
            Console.WriteLine(result);
        }

        public void GetDivision(int number, int denom, int parent = 0, int parentDiv = 0)
        {
            int div = 0;
            if (denom >= number)
            {
                div = denom / number;

                result += div + " X " + number;
                print(result);
                result = string.Empty;
                while (number != currency.Min() && div > 1)
                {
                    div--;

                    int[] smalleCurrency = currency.Where<int>(x => x < number).ToArray<int>();

                    foreach (int item in smalleCurrency)
                    {
                        if (smalleCurrency.Count() > 1 || parent != 0)
                        {
                            result += (parent != 0 ? parentDiv + " X " + parent.ToString() + " + " : string.Empty) + div + " X " + number + " + ";
                            int currentDenom = denom - (number * div);
                            GetDivision(item, currentDenom, number, div);
                        }
                        else
                        {
                            result += div + " X " + number + " + ";
                            int currentDenom = denom - (number * div);
                            GetDivision(item, currentDenom);
                        }
                    }
                }
            }
        }
    }
}
