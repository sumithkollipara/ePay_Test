﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Rest_Server.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerController : ControllerBase
    {
        public static Customer[] arrCustomer = new Customer[] { };

        List<string> firstNames = new List<string>() { "Leia", "Sadie", "Jose", "Sara", "Frank", "Dewey", "Tomas", "Joel", "Lukas", "Carlos" };
        List<string> lastNames = new List<string> { "Liberty", "Ray", "Harrison", "Ronan", "Drew", "Powell", "Larsen", "Chan", "Anderson", "Lane" };

        [HttpGet("{customerCount}")]
        public ActionResult PrepareCustomer(int customerCount)
        {
            try
            {
                if (customerCount < 2)
                    return new JsonResult(new { Message = "Please provide customerCount (atleast 2 Customer is mandatory to insert) " });

                Random random = new Random();
                int id = random.Next(1, 100);
                var customers = new List<Customer>();
                for (int i = 1; i <= customerCount; i++)
                {
                    int age = random.Next(10, 90);
                    customers.Add(new Customer() { age = age, firstName = firstNames[random.Next(firstNames.Count)], lastName = lastNames[random.Next(lastNames.Count)], id = id });
                    id = id + 1;
                }
                return new JsonResult(new { Data = JsonConvert.SerializeObject(customers) });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public ActionResult GetCustomer()
        {
            return new JsonResult(new { Data = JsonConvert.SerializeObject(arrCustomer) });
        }

        [HttpPost]
        public ActionResult PostCustomer(string customersPayload)
        {
            try
            {
                if (string.IsNullOrEmpty(customersPayload))
                    return new JsonResult(new { Message = "Please provide the JSON input with atleast 2 Customers." });

                var customers = JsonConvert.DeserializeObject<List<Customer>>(Regex.Unescape(customersPayload));

                if (customers == null || customers.Count < 2)
                    return new JsonResult(new { Message = "Please provide the JSON input with atleast 2 Customers." });

                foreach (var item in customers)
                {
                    if (!string.IsNullOrEmpty(item.firstName) && !string.IsNullOrEmpty(item.lastName) && item.id > 0 && item.age > 18)
                    {
                        if (arrCustomer.Where(i => i.id == item.id).FirstOrDefault() == null)
                        {
                            int insertPosition = GetSortedIndex(arrCustomer, item);
                            if (insertPosition >= 0)
                            {
                                Customer[] tempArray = arrCustomer;
                                arrCustomer = new Customer[tempArray.Length + 1];
                                for (int i = 0; i < arrCustomer.Length; i++)
                                {
                                    if (i < insertPosition)
                                        arrCustomer[i] = tempArray[i];
                                    else if (i == insertPosition)
                                        arrCustomer[i] = item;
                                    else
                                        arrCustomer[i] = tempArray[i - 1];
                                }
                            }
                        }
                    }
                }
                return new JsonResult(new { Data = JsonConvert.SerializeObject(arrCustomer) });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private int GetSortedIndex(Customer[] array, Customer value)
        {
            try
            {
                if (array.Length == 0)
                    return 0;
                int primaryIndex = 0;
                bool isMatch = false;
                List<int> matchIndexes = new List<int>();
                foreach (var item in array)
                {
                    if (string.Compare(item.lastName, value.lastName, StringComparison.OrdinalIgnoreCase) == 0)
                    {
                        isMatch = true;
                        matchIndexes.Add(Array.IndexOf(array, item));
                    }
                    else if (string.Compare(item.lastName, value.lastName, StringComparison.OrdinalIgnoreCase) > 0)
                    {
                        primaryIndex = Array.IndexOf(array, item);
                        if (!isMatch)
                            break;
                    }
                    else if (Array.IndexOf(array, item) == array.Length)
                    {
                        primaryIndex = array.Length + 1;
                        break;
                    }
                }
                if (isMatch)
                {
                    foreach (var index in matchIndexes)
                    {
                        if (String.Compare(array[index].firstName, value.firstName, StringComparison.OrdinalIgnoreCase) < 0)
                            primaryIndex = index + 1;
                        else
                            primaryIndex = index;
                    }
                }

                return primaryIndex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
