﻿namespace Rest_Server
{
    public class Customer
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public int age { get; set; }
        public int id { get; set; }
    }
}
